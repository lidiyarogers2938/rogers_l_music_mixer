# JavaScript Music Mixer

A music player that works in-browser with a predetermined track. When buttons or parts of the graphics are manipulated, aspects of the track, such as volume or speed, changes as well. The visualization component is manipulated along with the music using a combination of web audio API and ThreeJS(WebGL).

[Demo](https://amusejsmixer.appspot.com/)  

A [Learn IT, Girl](https://www.learnitgirl.com/second_edition) 2016 featured project. 
